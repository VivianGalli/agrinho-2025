function setup() {
  createCanvas(400, 400);
}

let xJogador1 = 0;
let xJogador2 = 0;
let xJogador3 = 0;
let xJogador4 = 0;

function draw() {
  ativaJogo();
  desenhaJogadores();
  desenhaLinhaDeChegada();
  verificaVencedor();
}

function ativaJogo() {
  if (focused == true) {
    background("green");
    textSize(50)
    text("Campo",110,50)
  } else {
    background("#C1A4F5");
    textSize(15)
      text("INSTRUÇÕES: Para começar você deve clicar no",10,30)
    text("play rosa no lado superior esquerdo,", 50, 50)
    text("e depois clique na tela do jogo,", 50,70)
    text("e a tela vai ficar verde, e você vai estar no campo,", 50,90)
    text("e para jogar você deve clicar nas teclas:", 50,110)
    text("'A' para andar com o primeiro", 50,130)
    text("'W' para andar com o segundo", 50,150)
    text(" e 'S' para andar com o terceiro ", 50,170)
    text(" o personagem vencedor será o que chegar", 50,190)
    text(" o primeiro na linha de chegada, no caso a cidade.", 50,210)
    text(" BOA SORTE!",50,230)
  }
}



function desenhaJogadores() {
  textSize(40);
  text("🐷", xJogador1, 120);
  text("🐮", xJogador2, 250);
  text("🤠", xJogador3, 185);
  text("🐰", xJogador4, 310);
}

function desenhaLinhaDeChegada() {
  fill("rgb(0,0,0)");
  rect(350, 0, 10, 400);
  fill("#FFFFFB");
  for (let yAtual = 0; yAtual < 400; yAtual += 20) {
    rect(350, yAtual, 10, 10);
  }
}

function verificaVencedor() {
  if (xJogador1 > 350) {
    text("🐷chegou na cidade!", 30, 200);
    noLoop();
  }
  if (xJogador2 > 350) {
    text("🐮chegou na cidade!", 30, 200);
    noLoop();
  }
  if (xJogador3 > 350) {
    text("🤠chegou na cidade!", 30, 200);
    noLoop();
  }
    if (xJogador4 > 350) {
    text("🐰chegou na cidade!", 30, 200);
    noLoop();
  }
}

function keyReleased() {
  if (key == "a") {
    xJogador1 += random(20);
  }
  if (key == "s") {
    xJogador2 += random(20);
  }
  if (key == "w") {
    xJogador3 += random(20);
  }
  if (key == "q") {
    xJogador4 += random(20);
  }
}
// o objetivo é chegar na cidade. (fiz no improviso pois oq eu estava querendo fazer não estava conseguindo)